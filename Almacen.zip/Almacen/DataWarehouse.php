<!DOCTYPE html>
<html lang = "en">
<head>
    <meta  charset="UTF-8">
    <title>Inventario</title>
    <link rel="stylesheet" href="css/main.css">
</head>
<body>
    <selection class="principal">
        <h1>Inventario</h1>
        <div class="form-1-2">
            <label for="cajaBusqueda">Buscar:</label>
            <input type="text" name="cajaBusqueda" id="cajaBusqueda">
        </div>
        <div id="datos">

        </div>
    </selection>
    <script src="js/jquery.min.js"></script>
    <script src="js/main.js"></script>
</body>
</html>
